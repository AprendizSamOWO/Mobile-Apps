package com.example.firstt

// Persona.kt
open class Persona(
    val nombre: String,
    val edad: Int
)
